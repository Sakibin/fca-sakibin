# Changelog
Too lazy to write changelog, sorry! (will write changelog in the next release, through.)